#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "treemap.h"

void treemap_init(treemap_t *tree) {
  tree->root = NULL;
  tree->size = 0;
}
// Initialize the given tree to have a null root and have size 0.

int treemap_add_step(node_t *node, char key[], char val[]) {
  int cmp = strcmp(key, node->key);
  if (cmp == 0) {
    strcpy(node->val, val);
    return 0;
  }
  if (cmp < 0) {
    if (node->left == NULL) {
      node_t *newNode = (node_t *)malloc(sizeof(node_t));
      strcpy(newNode->key, key);
      strcpy(newNode->val, val);
      newNode->left = NULL;
      newNode->right = NULL;
      node->left = newNode;
      return 1;
    }
    else {
      return treemap_add_step(node->left, key, val);
    }
  }
  else {
    if (node->right == NULL) {
      node_t *newNode = (node_t *)malloc(sizeof(node_t));
      strcpy(newNode->key, key);
      strcpy(newNode->val, val);
      newNode->left = NULL;
      newNode->right = NULL;
      node->right = newNode;
      return 1;
    }
    else {
      return treemap_add_step(node->right, key, val);
    }
  }
  //free(newNode);
}

int treemap_add(treemap_t *tree, char key[], char val[]) {
  if (tree->root == NULL) {
    node_t *node = (node_t *)malloc(sizeof(node_t));
    strcpy(node->key, key);
    strcpy(node->val, val);
    node->left = NULL;
    node->right = NULL;
    tree->root = node;
    tree->size = 1;
    return 1;
  }
  int result = treemap_add_step(tree->root, key, val);
  if (result == 1) {
    tree->size++;
  }
  return result;
  //free(node);
}
// Inserts given key/value into a binary search tree. Uses an
// ITERATIVE (loopy) approach to insertion which starts a pointer at
// the root of the tree and changes its location until the correct
// insertion point is located. If the key given already exists in the
// tree, no new node is created; the existing value is changed to the
// parameter 'val' and 0 is returned.  If no node with the given key
// is found, a new node is created and with the given key/val, added
// to the tree, and 1 is returned. Makes use of strcpy() to ease
// copying characters between memory locations.

char *treemap_get_step(node_t *node, char key[]) {
  int cmp = strcmp(key, node->key);
  if (cmp == 0) {
    return node->val;
  }
  if (cmp < 0) {
    if (node->left == NULL) {
      return NULL;
    }
    else {
      return treemap_get_step(node->left, key);
    }
  }
  else {
    if (node->right == NULL) {
      return NULL;
    }
    else {
      return treemap_get_step(node->right, key);
    }
  }
}

char *treemap_get(treemap_t *tree, char key[]) {
  if (tree->root == NULL) {
    return NULL;
  }
  return treemap_get_step(tree->root, key);
}
// Searches the tree for given 'key' and returns its associated
// value. Uses an ITERATIVE (loopy) search approach which starts a
// pointer at the root of the tree and changes it until the search key
// is found or determined not to be in the tree. If a matching key is
// found, returns a pointer to its value. If no matching key is found,
// returns NULL.
void treemap_clear(treemap_t *tree) {
  if (tree->root != NULL) {
    node_remove_all(tree->root);
    tree->root = NULL;
    tree->size = 0;
  }
}
// Eliminate all nodes in the tree setting its contents empty. Uses
// recursive node_remove_all() function to free memory for all nodes.

void node_remove_all(node_t *cur){
  if (cur->left != NULL) {
    node_remove_all(cur->left);
  }
  if (cur->right != NULL) {
    node_remove_all(cur->right);
  }
  free(cur);
}
// Recursive helper function which visits all nodes in a tree and
// frees the memory associated with them. This requires a post-order
// traversal: visit left tree, visit right tree, then free the cur
// node.

void treemap_print_revorder(treemap_t *tree) {
  if (tree->root == NULL) {
    return;
  }
  node_print_revorder(tree->root, 0);
}
// Prints the key/val pairs of the tree in reverse order at differing
// levels of indentation which shows all elements and their structure
// in the tree. Visually the tree can be rotated clockwise to see its
// structure. See the related node_print_revorder() for additional
// detals.

void node_print_revorder(node_t *cur, int indent) {
  if (cur->right != NULL) {
    node_print_revorder(cur->right, indent+1);
  }
  for (int i = 0; i<indent; i++) {
    printf("  ");
  }
  printf("%s -> %s\n", cur->key, cur->val);
  if (cur->left != NULL) {
    node_print_revorder(cur->left, indent+1);
  }
}
// Recursive helper function which prints all key/val pairs in the
// tree rooted at node 'cur' in reverse order. Traverses right
// subtree, prints cur node's key/val, then traverses left tree.
// Parameter 'indent' indicates how far to indent (2 spaces per indent
// level).
//
// For example: a if the root node "El" is passed into the function
// and it has the following structure:
// 
//         ___El->strange_____     
//        |                   |   
// Dustin->corny       ___Mike->stoic
//                    |              
//               Lucas->brash     
// 
// the recursive calls will print the following output:
// 
//   Mike -> stoic                 # root->right
//     Lucas -> brash              # root->right->left
// El -> strange                   # root
//   Dustin -> corny               # root->left

void treemap_print_preorder(treemap_t *tree) {
  if (tree->root == NULL) {
    return;
  }
  node_write_preorder(tree->root, stdout, 0);
}
// Print all the data in the tree in pre-order with indentation
// corresponding to the depth of the tree. Makes use of
// node_write_preorder() for this.

void treemap_save(treemap_t *tree, char *fname) {
  FILE *file = fopen(fname,"w");
  if (tree->root == NULL) {
    return;
  }
  node_write_preorder(tree->root, file, 0);
  fclose(file);
}
// Saves the tree by opening the named file, writing the tree to it in
// pre-order with node_write_preorder(), then closing the file.

void node_write_preorder(node_t *cur, FILE *out, int depth) {
  for (int i = 0; i<depth; i++) {
    fprintf(out,  "  ");
  }
  fprintf(out, "%s %s\n", cur->key, cur->val);
  if (cur->left != NULL) {
    node_write_preorder(cur->left, out, depth+1);
  }
  if (cur->right != NULL) {
    node_write_preorder(cur->right, out, depth+1);
  }
}
// Recursive helper function which writes/prints the tree in pre-order
// to the given open file handle. The parameter depth gives how far to
// indent node data, 2 spaces per unit depth. Depth increases by 1 on
// each recursive call. The function prints the cur node data,
// traverses the left tree, then traverses the right tree.

int treemap_load(treemap_t *tree, char *fname ) {
  //treemap_clear(tree);
  FILE *file = fopen(fname, "r");
  if (file == NULL) {
    printf("ERROR: could not open file '%s'\n", fname);
    return 0;
  }
  treemap_clear(tree);
  char key[128];
  char val[128];
  while (fscanf(file,"%s %s",key, val) != EOF) {
    treemap_add(tree, key, val);
  }
  fclose(file);
  return 1;
}
// Clears the given tree then loads new elements to it from the
// named. Repeated calls to treemap_insert() are used to add strings read
// from the file.  If the tree is stored in pre-order in the file, its
// exact structure will be restored.  Returns 1 if the tree is loaded
// successfully and 0 if opening the named file fails in which case no
// changes are made to the tree.

